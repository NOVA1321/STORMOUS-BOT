## No_Name_Bot
Install ...
```bash
apt install python3
apt install pip
pip install --upgrade pip
pip install -r requirements.txt
```
To run...
```bash
python3 bot.py
```
To run on background...
```bash
python3 bot.py --background
```
